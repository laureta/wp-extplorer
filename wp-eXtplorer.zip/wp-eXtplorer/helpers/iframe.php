<p>Find wp-eXtplorer useful? <a href='http://kulendra.net/Wordpress-Extensions/wp-extplorer.html'>Help us give you more, consider purchasing wp-eXtplorer for $5.50.</a></p>
<iframe src='<?php echo get_option('home').DS.'wp-content'.DS.'plugins'.DS.'wp-eXtplorer'.DS.'helpers'.DS;?>main.php' height="500px" width="900px"></iframe>
